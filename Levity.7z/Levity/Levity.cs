using Terraria.ModLoader;

namespace Levity
{
	class Levity : Mod
	{
		public Levity()
		{
		}
	}
}
